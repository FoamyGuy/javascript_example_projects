$date = document.getElementById("date");

$date.innerHTML = moment().format('MMMM Do YYYY');